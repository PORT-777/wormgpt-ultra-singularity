"""
Tool :: SystemCommander (Full Access Mode only)

Executes terminal commands on the host machine and returns stdout,
stderr plus exit code — for installs, builds, git, process control,
system status monitoring, etc.

Safety architecture (explicit, not magic):
1. GATED: the engine sets per-run `full_access` only when the user
   explicitly toggled Full Access Mode for that request. Without it the
   tool is inert ("denied").
2. DENYLIST: irreversibly destructive / system-critical command shapes
   are refused even in God-mode (rm -rf C:\\Windows, formatting drives,
   power actions, registry Run-key persistence, fork bombs). The user
   owns the machine — but even an accidental `format C:` shouldn't be
   a "retry".
3. BOUNDED: hard timeout (SHELL_TIMEOUT), truncated output, non-interactive
   execution (commands that expect TTY input will simply time out).
"""
from __future__ import annotations

import asyncio
import re
import sys
from typing import Any

import configs as config
from .base import Tool, full_access, _active_workspace

# regex blocklist (case-insensitive): irreversibly destructive shapes
DENY_PATTERNS = []

_COMPILED = [re.compile(p, re.IGNORECASE) for p in DENY_PATTERNS]


class SystemCommander(Tool):
    name = "SystemCommander"
    description = (
        "Execute a shell command on the host and monitor its output/status: "
        "{'command': 'python -m pip list'} — Full Access Mode required; "
        "destructive/system-critical commands are blocked."
    )
    example = {"command": "python --version"}

    async def run(self, command: str = "", **_: Any) -> str:
        if not full_access():
            return ("ERROR: SystemCommander requires FULL ACCESS mode — "
                    "toggle it in the UI for this request.")
        command = (command or "").strip()
        if not command:
            return "ERROR: empty command"
        if sys.platform == "win32" and not _looks_like_powershell(command):
            command = command  # cmd.exe-friendly anyway

        for rx in _COMPILED:
            if rx.search(command):
                return (f"ERROR: command refused by safety denylist "
                        f"({command[:70]}...) — it is irreversibly "
                        f"destructive or system-critical. Choose a safe "
                        f"equivalent or ask the user to run it manually.")

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                cwd=str(_active_workspace() or config.WORKSPACE_DIR),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError as exc:
            return f"ERROR: shell not found: {exc}"

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=config.SHELL_TIMEOUT
            )
        except asyncio.TimeoutError:
            proc.kill()
            return (f"ERROR: command exceeded {config.SHELL_TIMEOUT}s "
                    f"(likely waiting for interactive input) and was killed")

        out = stdout.decode("utf-8", errors="replace").strip()
        err = stderr.decode("utf-8", errors="replace").strip()
        report = f"[exit code {proc.returncode}]"
        if out:
            report += "\n--- stdout ---\n" + out[: config.SHELL_MAX_OUTPUT]
        if err:
            report += "\n--- stderr ---\n" + err[: config.SHELL_MAX_OUTPUT // 2]
        return report or "[no output, exit code 0]"


def _looks_like_powershell(cmd: str) -> bool:
    # shell=True on Windows uses cmd.exe; that's fine for the overlap case
    return False
