"""
WormGPT Ultra :: FastAPI Backend v4

Endpoints
---------
  POST /api/login      -> HMAC session token (only if ADMIN_PASSWORD set)
  POST /api/chat       -> SSE stream (full_access gated by auth when set)
  GET  /api/status     -> agent state + providers + auth_required flag
  GET  /api/models     -> provider availability
  GET  /api/history    -> sessions (SQLite, survives restarts)
  GET  /api/history/{sid}
  GET  /api/files      / POST /api/files / DELETE /api/files
  GET  /api/system     -> host status snapshot
  GET  /api/memory     -> RAG search/list    DELETE /api/memory
  GET  /api/audit      -> Full-access action trail (auth-gated)
  GET  /api/tasks      -> scheduled agent tasks   (auth-gated to create)
  POST /api/tasks      -> schedule {prompt, interval_minutes}
  DEL  /api/tasks/{id} -> remove
Run:
    uvicorn main:app --reload --port 8000
"""
from __future__ import annotations
try:
    import real_providers  # noqa: F401
    import compat_providers  # noqa: F401
except Exception:
    pass

import base64
import hashlib
import hmac
import asyncio
import json
import logging
import os
import re
import secrets
import shutil
import sys
import time
import uuid
import zipfile
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

import configs as config
import execution
import git_ops
import memory
import runtime_env
import user_memory
import sandbox as sandbox_mgr
import storage
import voice
from agent_engine import ENGINE
from fastapi import File, UploadFile
from fastapi.responses import FileResponse
from model_router import ROUTER

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("main")

# --------------------------------------------------------------------- #
#  Auth (JWT-lite: HMAC-signed tokens, stdlib only)
# --------------------------------------------------------------------- #
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "").strip()
AUTH_SECRET = (os.getenv("AUTH_SECRET", "").strip()
               or secrets.token_hex(32))
TOKEN_TTL = 12 * 3600  # 12h

AUTH_REQUIRED = bool(ADMIN_PASSWORD)


def _make_token() -> str:
    payload = json.dumps({"exp": time.time() + TOKEN_TTL}).encode()
    msg = base64.urlsafe_b64encode(payload).decode()
    sig = hmac.new(AUTH_SECRET.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return f"{msg}.{sig}"


def _verify_token(token: str) -> None:
    if not AUTH_REQUIRED:
        return
    if not token:
        raise HTTPException(401, "authentication required")
    try:
        msg, sig = token.split(".", 1)
        good = hmac.new(AUTH_SECRET.encode(), msg.encode(),
                        hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            raise ValueError
        payload = json.loads(base64.urlsafe_b64decode(msg))
        if payload.get("exp", 0) < time.time():
            raise ValueError("expired")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(401, "invalid or expired token")


def require_auth(authorization: str = Header(default="")) -> None:
    _verify_token(authorization.replace("Bearer ", "").strip())


@asynccontextmanager
async def lifespan(app: FastAPI):
    storage.init()                     # SQLite migrations
    from scheduler import SCHEDULER
    SCHEDULER.start()                  # background agent cron
    log.info("WormGPT Ultra booted | auth=%s | providers=%s",
             AUTH_REQUIRED, ROUTER.status())
    try:
        yield
    finally:
        await SCHEDULER.stop()
        try:
            from tools.browser_tool import shutdown_browser
            await shutdown_browser()
        except Exception:
            pass


app = FastAPI(title="WormGPT Ultra", version="4.0.0", lifespan=lifespan)

# Built frontend (vite) is served by the same origin when available, so the
# whole project can run on one URL (http://127.0.0.1:7777/).
_FRONTEND_DIST = Path(__file__).resolve().parents[1] / "frontend" / "dist"

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# CyberOps toolkit: /api/security/{capabilities,actions,run,health}
try:
    from security_api import router as _security_router
    app.include_router(_security_router)
except Exception as _exc:  # pragma: no cover - keep the app bootable
    logging.getLogger("main").warning("CyberOps API not mounted: %s", _exc)

# Gateway (providers/settings/models/squad) - mounted routes from gateway module
try:
    import gateway as _gateway
    for _r in list(_gateway.app.routes):
        try:
            app.routes.append(_r)
        except Exception:
            pass
    log.info("Gateway routes mounted (%d)", len(_gateway.app.routes))
except Exception as _gexc:
    log.warning("Gateway not mounted: %s", _gexc)


@app.get("/")
async def root():
    """Serve the built SPA, or a friendly JSON index if it isn't built."""
    index = _FRONTEND_DIST / "index.html"
    if index.is_file():
        return FileResponse(str(index), headers={"Cache-Control": "no-cache"})
    return {
        "ok": True,
        "service": "WormGPT Ultra — Singularity Edition",
        "ui": "http://localhost:5173",
        "docs": "/docs",
        "api": "/api/chat (POST, SSE)",
    }


# --------------------------------------------------------------------- #
#  Schemas
# --------------------------------------------------------------------- #
class ChatRequest(BaseModel):
    message: str = Field(min_length=1)
    session_id: Optional[str] = None
    model_route: Optional[str] = "auto"
    model: Optional[str] = None
    model_name: Optional[str] = None
    mode: Optional[str] = "code"
    system_prompt: Optional[str] = None
    depth: Optional[str] = "standard"
    full_access: bool = False
    # Universal execution: "off" (default), "auto", "cloud", "local",
    # "windows", "linux", "kali", "wsl", "android", "sandbox".
    exec_env: Optional[str] = None
    exec_task_id: Optional[str] = None
    exec_approved: bool = False
    # Files uploaded through the composer (info.path is relative to WORKSPACE_DIR)
    attachments: List[dict] = []


class FileRequest(BaseModel):
    action: str = "list"
    path: str = "."
    content: str = ""


class LoginRequest(BaseModel):
    password: str


class TaskRequest(BaseModel):
    prompt: str = Field(min_length=1)
    interval_minutes: int = Field(ge=1, le=10080)  # 1min .. 7 days


# --------------------------------------------------------------------- #
#  Auth endpoints
# --------------------------------------------------------------------- #
@app.post("/api/login")
async def login(req: LoginRequest):
    if not AUTH_REQUIRED:
        return {"token": "dev-open", "auth": False}
    if req.password != ADMIN_PASSWORD:
        raise HTTPException(401, "wrong password")
    return {"token": _make_token(), "auth": True}


class FeedbackRequest(BaseModel):
    session_id: str = ""
    message_id: str = ""
    vote: int = 0


class PromptEnhanceRequest(BaseModel):
    text: str = Field(min_length=1)
    mode: Optional[str] = "code"


# --------------------------------------------------------------------- #
#  Composer attachments -> real vision analysis
# --------------------------------------------------------------------- #
def _attachment_file(a: dict) -> Optional[Path]:
    """Resolve an uploaded attachment to a real file inside WORKSPACE_DIR."""
    if not isinstance(a, dict):
        return None
    info = a.get("info") if isinstance(a.get("info"), dict) else {}
    rel = str(info.get("path") or a.get("path") or "").strip()
    root = config.WORKSPACE_DIR.resolve()
    if rel:
        p = (root / rel).resolve()
        try:
            p.relative_to(root)
        except Exception:
            return None
        if p.is_file():
            return p
    name = Path(str(a.get("name") or "")).name
    if name:
        p = (root / "uploads" / name).resolve()
        if p.is_file():
            return p
    return None


async def _vision_prepare(attachments: List[dict],
                          question: str) -> tuple[str, dict]:
    """Describe every image attachment with a real vision model.

    Returns (text_block, info).  Non-image files are only mentioned by path
    so the agent can open them with its file tools.
    """
    import vision_service  # local import: keeps cold start light

    image_paths: List[Path] = []
    file_notes: List[str] = []
    for a in attachments or []:
        p = _attachment_file(a)
        if p is None:
            continue
        name = p.name
        if vision_service.is_image(p):
            image_paths.append(p)
        else:
            file_notes.append(f"[file: {name}] {p}")

    info: dict = {"ok": False, "provider": None, "model": None,
                  "images": len(image_paths), "files": len(file_notes)}
    if not image_paths:
        return "\n".join(file_notes), info

    asked = str(question or "").strip()
    q = ("Describe this image for the assistant. Include visible text, UI "
         "state, errors, diagrams and key objects. User request: "
         f"{(asked[:500] or '(none)')}")
    res = await asyncio.to_thread(vision_service.describe_images,
                                  [str(p) for p in image_paths], q)
    info.update({k: res.get(k) for k in
                 ("ok", "provider", "model", "items")})
    block = res.get("text") or ""
    parts = file_notes + ([f"[vision | {info.get('provider')}/"
                           f"{info.get('model')}]\n{block}"] if block else [])
    return "\n\n".join(parts), info


# --------------------------------------------------------------------- #
#  Chat -> SSE (with trace persistence for timeline/replay)
# --------------------------------------------------------------------- #
@app.post("/api/chat")
async def chat(req: ChatRequest, authorization: str = Header(default="")):
    # God-mode double gate: explicit flag AND (a valid token if auth is on)
    if req.full_access and AUTH_REQUIRED:
        _verify_token(authorization.replace("Bearer ", "").strip())

    sid = (req.session_id or uuid.uuid4().hex[:12]).strip() or uuid.uuid4().hex[:12]
    history = storage.get_history(sid)
    run_id = uuid.uuid4().hex[:12]
    try:
        storage.add_message(sid, "user", req.message, run_id=run_id)
    except TypeError:
        storage.add_message(sid, "user", req.message)

    # ---- Universal execution: resolve / create the task up-front ------- #
    exec_task_id: Optional[str] = None
    exec_notice: Optional[dict] = None
    try:
        if req.exec_task_id:
            t = execution.load_task(str(req.exec_task_id))
            if not t:
                exec_notice = {"ok": False,
                               "error": f"execution task {req.exec_task_id} not found"}
            else:
                exec_task_id = str(req.exec_task_id)
                exec_notice = {"ok": True, "task": execution.public_task(t),
                               "attached": True}
        elif req.exec_env and str(req.exec_env).strip().lower() not in ("", "off", "none", "chat"):
            t = execution.create_task(
                env=str(req.exec_env).strip().lower(),
                session_id=sid,
                title=str(req.message or "execution task")[:120],
                approved=bool(req.exec_approved),
            )
            exec_task_id = str(t["id"])
            exec_notice = {"ok": True, "task": t, "created": True}
    except execution.EnvironmentUnavailable as exc:
        exec_notice = {"ok": False, "error": exc.reason,
                       "available": exc.available, "requested": exc.requested}
        exec_task_id = None
    except Exception as exc:  # pragma: no cover
        log.warning("exec task setup failed: %s", exc)
        exec_notice = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        exec_task_id = None

    async def event_stream():
        reply = ""
        seq = 0
        vision_block, vision_info = "", {}
        if req.attachments:
            try:
                vision_block, vision_info = await _vision_prepare(
                    req.attachments, req.message)
            except Exception as exc:  # pragma: no cover
                log.warning("vision prepare failed: %s", exc)
                vision_info = {"ok": False, "error": str(exc)}
            if vision_info.get("images"):
                v_ev = {'type': 'vision',
                        'data': {'ok': bool(vision_info.get('ok')),
                                 'provider': vision_info.get('provider'),
                                 'model': vision_info.get('model'),
                                 'text': (vision_block or '')[:4000],
                                 'images': vision_info.get('images', 0)},
                        'run_id': run_id, 'seq': seq, 'ts': time.time()}
                yield f"data: {json.dumps(v_ev, ensure_ascii=False, default=str)}\n\n"
                seq += 1
        task_text = (f"{req.message}\n\n[vision]\n{vision_block}"
                     if vision_block else req.message)
        if exec_notice:
            yield f"data: {json.dumps({'type': 'exec', 'data': exec_notice, 'run_id': run_id, 'seq': seq, 'ts': time.time()}, ensure_ascii=False, default=str)}\n\n"
            seq += 1
        yield f"data: {json.dumps({'type':'run_start','data':{'session_id':sid,'run_id':run_id,'ts':time.time()}})}\n\n"
        try:
            execution.set_active_task(exec_task_id)
            async for event in ENGINE.run_stream(
                task_text, history=history,
                model_route=req.model_route or "auto",
                model_name=req.model_name or req.model or None,
                mode=req.mode or "code",
                full_access=bool(req.full_access),
                depth=req.depth or "standard",
                session_id=sid,
                system_prompt=req.system_prompt,
                exec_task_id=exec_task_id,
            ):
                seq += 1
                ev = dict(event or {})
                ev.setdefault("run_id", run_id)
                ev.setdefault("seq", seq)
                ev.setdefault("ts", time.time())
                etype = str(ev.get("type") or "event")
                if etype == "final":
                    reply = ev.get("data") if isinstance(ev.get("data"), str) else str(ev.get("data") or "")
                # Persist meaningful trace events for timeline/replay; skip high-volume stream chunks.
                if etype not in ("stream", "chunk", "token", "delta"):
                    try:
                        store_ev = ev
                        if etype == "observation":
                            # cap large tool outputs in DB
                            d = store_ev.get("data")
                            if isinstance(d, dict) and isinstance(d.get("output"), str) and len(d["output"]) > 12000:
                                d = dict(d); d["output"] = d["output"][:12000] + "\n...[truncated]"
                                store_ev = dict(store_ev); store_ev["data"] = d
                        storage.add_trace_event(sid, run_id, seq, etype, store_ev)
                    except Exception:
                        pass
                yield f"data: {json.dumps(ev, ensure_ascii=False, default=str)}\n\n"
        except Exception as exc:  # pragma: no cover
            log.exception("agent crashed")
            seq += 1
            err_ev = {'type': 'error', 'data': str(exc), 'run_id': run_id, 'seq': seq, 'ts': time.time()}
            try:
                storage.add_trace_event(sid, run_id, seq, 'error', err_ev)
            except Exception:
                pass
            yield f"data: {json.dumps(err_ev, ensure_ascii=False, default=str)}\n\n"
        finally:
            execution.set_active_task(None)
            if exec_task_id:
                try:
                    files = execution.list_files(exec_task_id).get("files", [])
                    if files and exec_notice and exec_notice.get("ok"):
                        art = execution.make_archive(exec_task_id)
                        seq += 1
                        art_ev = {'type': 'artifacts',
                                  'data': {'task_id': exec_task_id, 'artifacts': [art]},
                                  'run_id': run_id, 'seq': seq, 'ts': time.time()}
                        try:
                            storage.add_trace_event(sid, run_id, seq, 'artifacts', art_ev)
                        except Exception:
                            pass
                        yield f"data: {json.dumps(art_ev, ensure_ascii=False, default=str)}\n\n"
                except Exception as exc:
                    log.warning("auto-archive failed: %s", exc)
            try:
                storage.add_message(sid, "assistant", reply or "[no reply]", run_id=run_id)
            except TypeError:
                storage.add_message(sid, "assistant", reply or "[no reply]")
            done_ev = {'type': 'done', 'data': sid, 'run_id': run_id, 'seq': seq + 1, 'ts': time.time()}
            try:
                storage.add_trace_event(sid, run_id, seq + 1, 'done', done_ev)
            except Exception:
                pass
            yield f"data: {json.dumps(done_ev, ensure_ascii=False, default=str)}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/api/feedback")
async def feedback_submit(req: FeedbackRequest):
    try:
        vote = 1 if int(req.vote or 0) > 0 else (-1 if int(req.vote or 0) < 0 else 0)
        fid = storage.add_feedback(req.session_id or "", req.message_id or "", vote)
        try:
            storage.audit("feedback", f"session={req.session_id} message={req.message_id}", f"vote={vote}")
        except Exception:
            pass
        return {"ok": True, "id": fid, "vote": vote}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/prompt/enhance")
async def prompt_enhance(req: PromptEnhanceRequest):
    original = str(req.text or "").strip()
    mode = str(req.mode or "code").strip().lower()
    if not original:
        raise HTTPException(400, "text required")

    enhanced = ""
    # Best-effort: use agent brain/engine directly for a single-turn rewrite (no tools)
    try:
        from langchain_core.messages import HumanMessage, SystemMessage
        sys = (
            "You are a prompt enhancer. Rewrite the user's request into a clearer, more specific, high-quality prompt "
            "while preserving intent, constraints, and language. Do not answer the task. Do not add refusals or disclaimers. "
            "Return ONLY the improved prompt text."
        )
        if mode in ("plan", "planning"):
            sys += " Optimize for step-by-step planning and explicit deliverables."
        elif mode in ("debug",):
            sys += " Optimize for debugging: include symptoms, expected vs actual behavior, environment/context, and reproduction details placeholders if missing."
        elif mode in ("research", "ask"):
            sys += " Optimize for research/analysis with clear scope, sources/evidence expectations, and output format."
        brain = None
        try:
            # Prefer current engine brain without running tools
            if hasattr(ENGINE, '_select_brain'):
                brain = ENGINE._select_brain(getattr(ENGINE, 'active_route', 'auto') or 'auto', original)
            elif hasattr(ENGINE, 'llm'):
                brain = ENGINE.llm
        except Exception:
            brain = None
        if brain is not None and hasattr(brain, 'ainvoke'):
            msgs = [SystemMessage(content=sys), HumanMessage(content=original[:12000])]
            out = await brain.ainvoke(msgs)
            enhanced = getattr(out, 'content', out)
            if isinstance(enhanced, list):
                parts = []
                for part in enhanced:
                    if isinstance(part, dict): parts.append(str(part.get('text') or part.get('content') or ''))
                    else: parts.append(str(part))
                enhanced = ''.join(parts)
            enhanced = str(enhanced or '').strip()
    except Exception as e:
        log.warning("prompt_enhance brain failed: %s", e)

    # Fallback: deterministic structural enhancement (no external dependency)
    if not enhanced or len(enhanced) < max(10, len(original)//2):
        lines = [l.rstrip() for l in original.splitlines() if l.strip()]
        core = " ".join(lines).strip()
        if mode == "debug":
            enhanced = (
                f"Task: Debug the issue.\n"
                f"Context/Request: {core}\n"
                f"Expected behavior: [fill if known]\n"
                f"Actual behavior: [fill if known]\n"
                f"Environment/versions: [fill if relevant]\n"
                f"Steps to reproduce: [fill if relevant]\n"
                f"Deliverables: identify root cause, propose fix, and provide exact code/commands."
            )
        elif mode in ("plan", "planning"):
            enhanced = (
                f"Goal: {core}\n"
                f"Constraints: [list any constraints]\n"
                f"Deliverables: [explicit outputs/files]\n"
                f"Please produce: a clear step-by-step plan, risks/assumptions, and verification steps."
            )
        else:
            enhanced = (
                f"Goal: {core}\n"
                f"Requirements:\n- Be specific and complete.\n- Preserve all user constraints.\n- State assumptions if needed.\n"
                f"Deliverables: [code/files/analysis as applicable]\n"
                f"Output format: clear, structured, and actionable."
            )
        enhanced = enhanced.strip()

    # avoid runaway or identical noise
    if not enhanced:
        enhanced = original
    if enhanced == original and len(original) < 200:
        enhanced = f"{original}\n\nPlease provide a complete, specific, and actionable response with any assumptions stated."

    return {"ok": True, "text": enhanced[:12000], "mode": mode, "original_length": len(original)}



# --------------------------------------------------------------------- #
#  Multi-model compare (gateway providers, parallel, best-effort)
# --------------------------------------------------------------------- #
class CompareRequest(BaseModel):
    prompt: str = Field(min_length=1)
    models: List[str] = Field(default_factory=list)  # ["providerId::modelId", ...] or ["modelId"]
    max_tokens: int = Field(default=700, ge=64, le=4096)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    system_prompt: Optional[str] = None


def _resolve_compare_targets(model_refs: List[str], limit: int = 6):
    try:
        import gateway as gw
        db = gw.DB
        providers = [p for p in (db.get('providers') or []) if p.get('enabled') and p.get('status') == 'ok' and str(p.get('key') or '').strip()]
        g = gw.gateway_settings() if hasattr(gw, 'gateway_settings') else (db.get('settings') or {})
        global_free = bool((g or {}).get('freeOnly'))
    except Exception:
        providers = []
        global_free = False
    by_id = {str(p.get('id')): p for p in providers}
    by_name = {str(p.get('name') or '').lower(): p for p in providers}

    def eligible_models(p: dict):
        ms = p.get('_models') or []
        if not isinstance(ms, list): ms = []
        ms = [str(x) for x in ms if str(x).strip()]
        meta = p.get('_meta') if isinstance(p.get('_meta'), dict) else {}
        free_ids = set(str(x) for x in (meta.get('free_ids') or []) if str(x).strip()) if isinstance(meta.get('free_ids'), list) else set()
        fo = global_free or bool(p.get('freeOnly')) or str(p.get('tier') or '').lower() == 'free'
        def is_free(m):
            ml = m.lower()
            return (m in free_ids) or (':free' in ml) or ml.endswith('/free') or ('/free' == ml[-5:] if len(ml)>=5 else False)
        if fo:
            pref = [m for m in ms if is_free(m)]
            if pref: return pref
            # if provider marked free tier but no explicit free ids, allow listed models (policy-based)
            if str(p.get('tier') or '').lower() == 'free':
                return ms
            return []
        # non-free-only: prefer free first for safer auto-compare, then others
        pref = [m for m in ms if is_free(m)] + [m for m in ms if not is_free(m)]
        return pref or ms

    targets = []
    refs = [str(x or '').strip() for x in (model_refs or []) if str(x or '').strip()]
    if not refs:
        # auto-pick: up to 3 providers, first eligible model each
        for p in providers:
            if len(targets) >= 3: break
            em = eligible_models(p)
            if em:
                targets.append((p, str(em[0])))
        # if none due to strict free-only, relax to any available model
        if not targets:
            for p in providers[:3]:
                ms = p.get('_models') or []
                if isinstance(ms, list) and ms:
                    targets.append((p, str(ms[0])))
        return targets[:limit]

    for ref in refs:
        if len(targets) >= limit:
            break
        pid = ""; mid = ""
        if "::" in ref:
            pid, mid = ref.split("::", 1); pid, mid = pid.strip(), mid.strip()
        elif "/" in ref and ref.split("/",1)[0] in by_id:
            pid, mid = ref.split("/",1); pid, mid = pid.strip(), mid.strip()
        else:
            mid = ref.strip()
        prov = by_id.get(pid) or by_name.get(pid.lower()) if pid else None
        if prov and mid:
            targets.append((prov, mid)); continue
        # search model id across providers (prefer eligible)
        found = None
        for p in providers:
            em = eligible_models(p) or [str(x) for x in (p.get('_models') or []) if str(x).strip()]
            if mid and mid in em:
                found = (p, mid); break
        if not found and mid:
            for p in providers:
                ms = [str(x) for x in (p.get('_models') or []) if str(x).strip()] if isinstance(p.get('_models'), list) else []
                if mid in ms:
                    found = (p, mid); break
        if found:
            targets.append(found); continue
        if prov:
            em = eligible_models(prov)
            if em: targets.append((prov, str(em[0])))
    # de-dupe
    out=[]; seen=set()
    for p,m in targets:
        k=(str(p.get('id')), str(m))
        if k in seen: continue
        seen.add(k); out.append((p,m))
    return out[:limit]


async def _compare_one(provider: dict, model: str, prompt: str, system_prompt: str = "", max_tokens: int = 700, temperature: float = 0.2):
    import httpx
    base = str(provider.get('baseUrl') or provider.get('base_url') or '').rstrip('/')
    key = str(provider.get('key') or '')
    url = base if base.endswith('/chat/completions') else base + '/chat/completions'
    headers = {'Content-Type': 'application/json'}
    if key:
        headers['Authorization'] = f'Bearer {key}'
    msgs = []
    if system_prompt:
        msgs.append({'role':'system','content': str(system_prompt)[:12000]})
    msgs.append({'role':'user','content': str(prompt)[:24000]})
    payload = {'model': model, 'messages': msgs, 'max_tokens': int(max_tokens or 700), 'temperature': float(temperature)}
    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=90.0) as client:
            r = await client.post(url, headers=headers, json=payload)
        ms = int((time.perf_counter()-t0)*1000)
        if r.status_code >= 400:
            detail = ''
            try: detail = (r.json().get('error',{}) or {}).get('message') if r.headers.get('content-type','').startswith('application/json') else r.text[:300]
            except Exception: detail = (r.text or '')[:300]
            return {'ok': False, 'provider': provider.get('name'), 'provider_id': provider.get('id'), 'model': model, 'ms': ms, 'status': r.status_code, 'error': str(detail or f'HTTP {r.status_code}')[:500]}
        data = r.json() if r.content else {}
        content = ''
        try:
            content = (((data.get('choices') or [{}])[0] or {}).get('message') or {}).get('content') or ''
        except Exception:
            content = ''
        if isinstance(content, list):
            parts=[]
            for part in content:
                if isinstance(part, dict): parts.append(str(part.get('text') or part.get('content') or ''))
                else: parts.append(str(part))
            content = ''.join(parts)
        usage = data.get('usage') if isinstance(data.get('usage'), dict) else {}
        return {'ok': True, 'provider': provider.get('name'), 'provider_id': provider.get('id'), 'model': model, 'ms': ms, 'status': r.status_code, 'content': str(content or ''), 'usage': usage}
    except Exception as e:
        ms = int((time.perf_counter()-t0)*1000)
        return {'ok': False, 'provider': provider.get('name'), 'provider_id': provider.get('id'), 'model': model, 'ms': ms, 'error': f'{type(e).__name__}: {str(e)[:300]}'}


@app.post("/api/compare")
@app.post("/api/gateway/compare")
async def compare_models(req: CompareRequest):
    targets = _resolve_compare_targets(req.models or [], limit=6)
    if not targets:
        raise HTTPException(400, "no working provider models available for compare (enable/test/sync providers first)")
    sem = asyncio.Semaphore(4)
    async def run_one(p,m):
        async with sem:
            return await _compare_one(p,m,req.prompt,req.system_prompt or "",req.max_tokens,req.temperature)
    results = await asyncio.gather(*[run_one(p,m) for p,m in targets], return_exceptions=False)
    ok = [r for r in results if r.get('ok')]
    primary = None
    if ok:
        def score(r):
            c = str(r.get('content') or '')
            # prefer substantive, non-refusal-like, fenced/structured answers, lower latency
            fence_bonus = 200 if '```' in c else 0
            len_score = min(len(c), 8000)
            refusal_penalty = 5000 if re.search(r"(?i)\b(i can't|i cannot|cannot assist|cannot provide|as an ai)\b", c) else 0
            return (len_score + fence_bonus - refusal_penalty, -int(r.get('ms') or 0))
        primary = sorted(ok, key=score, reverse=True)[0]
    return {
        'prompt': req.prompt,
        'count': len(results),
        'ok_count': len(ok),
        'results': results,
        'primary': primary,
        'compared_at': time.time(),
    }


# --------------------------------------------------------------------- #
#  Status / models / history / system
# --------------------------------------------------------------------- #
@app.get("/api/status")
async def status():
    return {
        "state": ENGINE.status,
        "route": ENGINE.active_route,
        "providers": ROUTER.status(),
        "auth_required": AUTH_REQUIRED,
    }


@app.get("/api/models")
async def models():
    return {"providers": ROUTER.status()}


@app.get("/api/history")
async def history_list(q: str = ""):
    return storage.list_sessions(q=q)


@app.get("/api/history/{session_id}")
async def history_get(session_id: str, full: int = 0, limit: int = 200):
    if full:
        try:
            return storage.get_session_messages(session_id, limit=max(1, min(limit, 5000)), asc=True)
        except Exception:
            pass
    return storage.get_history(session_id, limit=max(1, min(limit, 2000)))


@app.get("/api/history/{session_id}/detail")
async def history_detail(session_id: str, limit: int = 500):
    sess = storage.get_session(session_id)
    if not sess:
        # The UI creates a local session id before the first message is sent;
        # treat it as empty rather than an error so panels stay quiet.
        return {"session": None, "messages": [], "session_found": False}
    return {"session": sess, "messages": storage.get_session_messages(session_id, limit=max(1, min(limit, 5000)), asc=True), "session_found": True}


@app.get("/api/history/{session_id}/trace")
async def history_trace(session_id: str, run_id: str = "", limit: int = 2000):
    try:
        items = storage.list_trace_events(session_id, run_id=run_id, limit=max(1, min(limit, 10000)))
    except Exception:
        items = []
    return {"session_id": session_id, "run_id": run_id, "items": items, "count": len(items)}


@app.get("/api/history/{session_id}/export")
async def history_export(session_id: str, limit: int = 2000):
    try:
        data = storage.get_session_export(session_id, message_limit=max(1, min(limit, 10000)))
    except Exception:
        data = None
    if not data:
        # Unknown / not-yet-persisted session: exportable but empty.
        return {"session": None, "messages": [], "trace_events": [],
                "session_found": False}
    return data


@app.get("/api/timeline/{session_id}")
async def timeline_get(session_id: str, run_id: str = "", limit: int = 2000):
    sess = storage.get_session(session_id)
    if not sess:
        # Session ids are minted client-side; an unsaved session has no
        # history yet. Answer with an empty timeline instead of 404.
        return {"session": None, "messages": [], "trace_events": [],
                "run_id": run_id, "session_found": False}
    msgs = []
    try:
        msgs = storage.get_session_messages(session_id, limit=max(1, min(limit, 5000)), asc=True)
    except Exception:
        msgs = storage.get_history(session_id, limit=max(1, min(limit, 500)))
    try:
        traces = storage.list_trace_events(session_id, run_id=run_id, limit=max(1, min(limit, 10000)))
    except Exception:
        traces = []
    return {"session": sess, "messages": msgs, "trace_events": traces, "run_id": run_id,
            "session_found": True}

@app.get("/api/history/{session_id}/runs")
async def history_runs(session_id: str, limit: int = 2000):
    sess = storage.get_session(session_id)
    if not sess:
        # Stale tabs keep polling deleted sessions: answer with an empty
        # run list instead of a 404 so the UI stays quiet.
        return {"session_id": session_id, "runs": [], "count": 0,
                "session_found": False}
    try:
        events = storage.list_trace_events(session_id, run_id="", limit=max(1, min(limit, 10000)))
    except Exception:
        events = []
    runs = {}
    for ev in events:
        rid = str(ev.get('run_id') or '')
        if not rid:
            continue
        r = runs.setdefault(rid, {"run_id": rid, "count": 0, "kinds": {}, "first_ts": ev.get('ts'), "last_ts": ev.get('ts'), "has_error": False, "has_final": False})
        r["count"] += 1
        k = str(ev.get('kind') or ev.get('type') or '')
        r["kinds"][k] = r["kinds"].get(k, 0) + 1
        ts = ev.get('ts')
        if ts is not None:
            if r["first_ts"] is None or ts < r["first_ts"]: r["first_ts"] = ts
            if r["last_ts"] is None or ts > r["last_ts"]: r["last_ts"] = ts
        if k == 'error': r["has_error"] = True
        if k == 'final': r["has_final"] = True
    out = sorted(runs.values(), key=lambda x: (x.get('last_ts') or 0), reverse=True)
    return {"session_id": session_id, "runs": out, "count": len(out),
            "session_found": True}



@app.delete("/api/history/{session_id}")
async def history_delete(session_id: str):
    try:
        return {"deleted_messages": storage.delete_session(session_id)}
    except KeyError:
        raise HTTPException(404, "session not found")


# --------------------------------------------------------------------- #
#  Sessions API — aliases the sidebar expects (/api/sessions/...)
#  Previously only /api/history/{id} existed, so delete/rename/pin from
#  the sidebar failed with HTTP 405 Method Not Allowed.
# --------------------------------------------------------------------- #
class SessionPatchRequest(BaseModel):
    id: Optional[str] = None
    title: Optional[str] = None
    pinned: Optional[bool] = None


@app.post("/api/sessions")
async def sessions_create(req: Optional[SessionPatchRequest] = None):
    """Create an empty session. Accepts optional {id, title, pinned}."""
    sid = uuid.uuid4().hex[:12]
    title = "new session"
    pinned = False
    if req is not None:
        if getattr(req, "id", None):
            sid = str(req.id)[:64]
        if req.title:
            title = str(req.title)[:200]
        if req.pinned is not None:
            pinned = bool(req.pinned)
    storage.ensure_session(sid, title)
    if pinned:
        storage.patch_session(sid, pinned=True)
    return {"ok": True, "session": storage.get_session(sid)}


@app.get("/api/sessions")
async def sessions_list(q: str = ""):
    return storage.list_sessions(q)


@app.get("/api/sessions/{session_id}")
async def sessions_get(session_id: str):
    sess = storage.get_session(session_id)
    if not sess:
        raise HTTPException(404, "session not found")
    return sess


@app.patch("/api/sessions/{session_id}")
async def sessions_patch(session_id: str, req: SessionPatchRequest):
    sess = storage.patch_session(session_id, title=req.title, pinned=req.pinned)
    if not sess:
        raise HTTPException(404, "session not found")
    return {"ok": True, "session": sess}


@app.post("/api/sessions/{session_id}/duplicate")
async def sessions_duplicate(session_id: str):
    new_id = uuid.uuid4().hex[:12]
    sess = storage.duplicate_session(session_id, new_id)
    if not sess:
        raise HTTPException(404, "session not found")
    return {"ok": True, "session": sess}


@app.delete("/api/sessions/{session_id}")
async def sessions_delete(session_id: str):
    try:
        return {"ok": True, "deleted_messages": storage.delete_session(session_id)}
    except KeyError:
        raise HTTPException(404, "session not found")


@app.delete("/api/sessions")
async def sessions_delete_all():
    """Wipe every stored session (used by the sidebar's clear-all button)."""
    try:
        result = storage.delete_all_sessions()
        storage.audit("sessions_clear_all", json.dumps(result))
        return {"ok": True, **result}
    except Exception as e:
        raise HTTPException(500, f"clear all failed: {e}")


# --------------------------------------------------------------------- #
#  Gamification: XP, levels, achievements, streaks (SQLite-backed)
# --------------------------------------------------------------------- #
try:
    import gamification as gamif
except Exception as _gmexc:  # pragma: no cover - keep the app bootable
    gamif = None  # type: ignore[assignment]
    log.warning("Gamification not mounted: %s", _gmexc)


class AwardRequest(BaseModel):
    event: str
    user_id: str = "operator"
    amount: Optional[int] = None
    meta: Optional[dict] = None


# --------------------------------------------------------------------- #
#  Saved prompts (prompt_library) + MCP servers (mcp_manager)
# --------------------------------------------------------------------- #
class PromptRequest(BaseModel):
    title: str
    content: str
    tags: Optional[List[str]] = None
    favorite: bool = False
    model: Optional[str] = None


class PromptPatch(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    tags: Optional[List[str]] = None
    favorite: Optional[bool] = None
    model: Optional[str] = None


class McpServerRequest(BaseModel):
    name: str
    spec: dict = Field(default_factory=dict)


@app.get("/api/prompts")
async def prompts_list(q: str = "", tag: str = "", favorite: bool = False):
    try:
        import prompt_library
        return {"items": prompt_library.search(q, tag or None, favorite)}
    except Exception as exc:
        raise HTTPException(503, f"prompt library unavailable: {exc}")


@app.post("/api/prompts")
async def prompts_create(req: PromptRequest):
    try:
        import prompt_library
        return {"ok": True, "prompt": prompt_library.create(
            req.title.strip()[:200], req.content, tags=req.tags,
            favorite=bool(req.favorite), model=req.model)}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.patch("/api/prompts/{prompt_id}")
async def prompts_update(prompt_id: str, req: PromptPatch):
    try:
        import prompt_library
        patch = {k: v for k, v in req.model_dump().items() if v is not None}
        p = prompt_library.update(prompt_id, **patch)
        if not p:
            raise HTTPException(404, "prompt not found")
        return {"ok": True, "prompt": p}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.delete("/api/prompts/{prompt_id}")
async def prompts_delete(prompt_id: str):
    try:
        import prompt_library
        return {"ok": bool(prompt_library.delete(prompt_id))}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/mcp")
async def mcp_status():
    try:
        import mcp_manager
        return {**mcp_manager.status(), "servers": mcp_manager.list_servers()}
    except Exception as exc:
        raise HTTPException(503, f"mcp manager unavailable: {exc}")


@app.post("/api/mcp")
async def mcp_upsert(req: McpServerRequest):
    try:
        import mcp_manager
        return mcp_manager.upsert_server(req.name, req.spec or {})
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.delete("/api/mcp/{name}")
async def mcp_delete(name: str):
    try:
        import mcp_manager
        return mcp_manager.remove_server(name)
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/mcp/{name}/test")
async def mcp_test(name: str):
    try:
        import mcp_manager
        return await mcp_manager.test_server(name)
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/gamification/state")
async def gamification_state(user_id: str = "operator"):
    if gamif is None:
        raise HTTPException(503, "gamification unavailable")
    return gamif.state(user_id)


@app.get("/api/gamification/catalog")
async def gamification_catalog():
    if gamif is None:
        raise HTTPException(503, "gamification unavailable")
    return gamif.catalog()


@app.post("/api/gamification/award")
async def gamification_award(req: AwardRequest):
    if gamif is None:
        raise HTTPException(503, "gamification unavailable")
    try:
        return gamif.award(req.event, req.user_id, req.amount, req.meta)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(500, f"award failed: {e}")


@app.post("/api/gamification/reset")
async def gamification_reset(user_id: str = "operator"):
    if gamif is None:
        raise HTTPException(503, "gamification unavailable")
    return gamif.reset(user_id)


@app.get("/api/version")
async def version_info():
    """Build stamp shown in the footer (build id = dist bundle hash)."""
    build = ""
    try:
        index = Path(__file__).resolve().parent.parent / "frontend" / "dist" / "index.html"
        html = index.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r"assets/index-([\w-]+)\.js", html)
        build = m.group(1) if m else ""
    except Exception:
        pass
    return {"version": app.version, "build": build, "server": "uvicorn",
            "python": sys.version.split()[0], "platform": sys.platform}


# --------------------------------------------------------------------- #
#  Checkpoints — the UI reads/diffs/reverts workspace snapshots that the
#  agent engine already creates (backend/checkpoint.py).
# --------------------------------------------------------------------- #
try:
    import checkpoint as checkpoint_store
except Exception as _ckexc:  # pragma: no cover
    checkpoint_store = None  # type: ignore[assignment]
    log.warning("Checkpoints not mounted: %s", _ckexc)


@app.get("/api/checkpoints")
async def checkpoints_list(session_id: str = ""):
    if checkpoint_store is None:
        raise HTTPException(503, "checkpoints unavailable")
    if not session_id:
        return {"ok": True, "checkpoints": []}
    try:
        return {"ok": True, "checkpoints": checkpoint_store.list_checkpoints(session_id)}
    except FileNotFoundError:
        return {"ok": True, "checkpoints": []}
    except Exception as e:
        raise HTTPException(500, f"list checkpoints failed: {e}")


@app.get("/api/checkpoints/{checkpoint_id}/diff")
async def checkpoints_diff(checkpoint_id: str, session_id: str = ""):
    if checkpoint_store is None:
        raise HTTPException(503, "checkpoints unavailable")
    try:
        return {"ok": True, "diff": checkpoint_store.diff_checkpoint(checkpoint_id, session_id)}
    except FileNotFoundError:
        raise HTTPException(404, "checkpoint not found")
    except Exception as e:
        raise HTTPException(500, f"diff failed: {e}")


@app.post("/api/checkpoints/{checkpoint_id}/revert")
async def checkpoints_revert(checkpoint_id: str, session_id: str = ""):
    if checkpoint_store is None:
        raise HTTPException(503, "checkpoints unavailable")
    try:
        result = checkpoint_store.revert_checkpoint(checkpoint_id, session_id)
        storage.audit("checkpoint_revert", json.dumps({"id": checkpoint_id, "session": session_id}))
        return {"ok": True, **(result or {})}
    except FileNotFoundError:
        raise HTTPException(404, "checkpoint not found")
    except Exception as e:
        raise HTTPException(500, f"revert failed: {e}")


@app.get("/api/system")
async def system_status():
    usage = shutil.disk_usage(str(config.WORKSPACE_DIR))
    return {
        "platform": sys.platform,
        "python": sys.version.split()[0],
        "workspace_writeable": os.access(config.WORKSPACE_DIR, os.W_OK),
        "disk_total_gb": round(usage.total / 1e9, 1),
        "disk_free_gb": round(usage.free / 1e9, 1),
    }


@app.get("/api/health")
async def health():
    return {"ok": True, "workspace": str(config.WORKSPACE_DIR),
            "auth": AUTH_REQUIRED}


@app.get("/health")
async def health_root():
    return {"ok": True, "workspace": str(config.WORKSPACE_DIR),
            "auth": AUTH_REQUIRED}


# --------------------------------------------------------------------- #
#  Voice: Whisper STT + offline TTS
# --------------------------------------------------------------------- #
@app.post("/api/transcribe")
async def transcribe(file: UploadFile = File(...),
                     language: Optional[str] = None):
    data = await file.read()
    suffix = Path(file.filename or "a.webm").suffix or ".webm"
    text = await voice.transcribe(data, suffix=suffix, language=language)
    return {"text": text, "ok": not text.startswith("ERROR")}


@app.get("/api/tts")
async def tts(text: str):
    wav = await voice.synthesize(text)
    if wav is None:
        raise HTTPException(
            503, "tts unavailable — install pyttsx3 (pip install pyttsx3)")
    return FileResponse(str(wav), media_type="audio/wav",
                        filename="wormgpt.wav")


# --------------------------------------------------------------------- #
#  Deep memory: workspace files index
# --------------------------------------------------------------------- #
@app.post("/api/memory/index")
async def memory_index(_=Depends(require_auth)):
    indexed = await asyncio.to_thread(memory.index_workspace)
    return {"indexed_chunks": indexed}


# --------------------------------------------------------------------- #
#  Audit trail (Full Access actions)
# --------------------------------------------------------------------- #
@app.get("/api/audit")
async def audit_list(limit: int = 100, _=Depends(require_auth)):
    return {"items": storage.get_audit(limit)}


# --------------------------------------------------------------------- #
#  Scheduled background tasks
# --------------------------------------------------------------------- #
@app.get("/api/tasks")
async def tasks_list(_=Depends(require_auth)):
    return storage.list_tasks()


@app.post("/api/tasks")
async def task_create(req: TaskRequest, authorization: str = Header(default="")):
    _verify_token(authorization.replace("Bearer ", "").strip())
    task_id = storage.add_task(req.prompt, req.interval_minutes)
    log.info("scheduled task #%s every %s min", task_id,
             req.interval_minutes)
    return {"id": task_id, "interval_minutes": req.interval_minutes}


@app.delete("/api/tasks/{task_id}")
async def task_delete(task_id: int, authorization: str = Header(default="")):
    _verify_token(authorization.replace("Bearer ", "").strip())
    return {"deleted": storage.remove_task(task_id)}


# --------------------------------------------------------------------- #
#  Change proposals (human-in-the-loop self-improvement)
# --------------------------------------------------------------------- #
@app.get("/api/proposals")
async def proposals_list(status: Optional[str] = None):
    try:
        import proposals as _pro
        return _pro.list_proposals(status)
    except Exception as exc:
        raise HTTPException(500, str(exc))


@app.post("/api/proposals/{pid}/approve", dependencies=[Depends(require_auth)])
async def proposals_approve(pid: int):
    import proposals as _pro
    result = await asyncio.to_thread(_pro.apply_proposal, pid)
    if not result.get("ok"):
        raise HTTPException(409 if "already" in result.get("error", "")
                            else 404, result.get("error", "apply failed"))
    return result


@app.post("/api/proposals/{pid}/reject", dependencies=[Depends(require_auth)])
async def proposals_reject(pid: int):
    import proposals as _pro
    result = await asyncio.to_thread(_pro.reject, pid)
    if not result.get("ok"):
        raise HTTPException(409 if "already" in result.get("error", "")
                            else 404, result.get("error", "reject failed"))
    return result


# --------------------------------------------------------------------- #
#  File management (workspace sandbox)
# --------------------------------------------------------------------- #
MAX_UPLOAD = 200 * 1024 * 1024      # 200 MB "intelligence input" cap


@app.post("/api/files/upload")
async def files_upload(file: UploadFile = File(...),
                       subdir: str = "uploads"):
    """Intelligence-inputs protocol: any file lands in the sandbox and
    returns an instant profile (type guess, size, text preview) so the
    agent can analyse source/binaries/data files immediately."""
    data = await file.read()
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, f"file too large (> {MAX_UPLOAD // 1048576}MB)")

    name = Path(file.filename or "upload.bin").name   # no traversal
    target = _safe(f"{subdir.strip('/')}/{name}")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

    suffix = target.suffix.lower()
    text_like = suffix in (".cpp", ".h", ".py", ".js", ".json", ".txt",
                           ".md", ".asm", ".ini", ".yaml", ".yml",
                           ".xml", ".csv", ".log")
    profile = {
        "path": str(target.relative_to(config.WORKSPACE_DIR)),
        "size": len(data),
        "kind": ("image" if suffix in (".png", ".jpg", ".jpeg", ".webp",
                                       ".gif", ".bmp")
                 else "archive" if suffix in (".zip", ".tar", ".gz", ".rar")
                 else "text" if text_like
                 else "binary" if suffix in (".bin", ".exe", ".dll",
                                             ".dat", ".so", ".lib")
                 else "unknown"),
    }
    if text_like:
        preview = data[:4000].decode("utf-8", errors="replace")
        profile["preview"] = preview
    return profile


@app.get("/api/files")
async def files_list():
    root = config.WORKSPACE_DIR

    def walk(p: Path, depth: int = 0):
        items = []
        try:
            for child in sorted(p.iterdir()):
                items.append({
                    "name": child.name,
                    "path": str(child.relative_to(root)),
                    "is_dir": child.is_dir(),
                    "size": child.stat().st_size if child.is_file() else 0,
                    "depth": depth,
                })
                if child.is_dir() and depth < 4:
                    items.extend(walk(child, depth + 1))
        except PermissionError:
            pass
        return items

    return {"root": str(root), "files": walk(root)}


def _safe(path: str) -> Path:
    root = config.WORKSPACE_DIR.resolve()
    target = (root / path.lstrip("/\\")).resolve()
    if root != target and root not in target.parents:
        raise HTTPException(400, "path escapes workspace sandbox")
    return target


@app.post("/api/files")
async def files_ops(req: FileRequest):
    action = req.action.lower()
    try:
        if action == "list":
            return await files_list()
        if action == "read":
            if _is_sensitive(req.path):
                raise HTTPException(403, "sensitive file blocked")
            t = _safe(req.path)
            if not t.is_file():
                raise HTTPException(404, "not a file")
            return {"path": req.path,
                    "content": t.read_text(encoding="utf-8",
                                           errors="replace")}
        if action == "write":
            t = _safe(req.path)
            t.parent.mkdir(parents=True, exist_ok=True)
            t.write_text(req.content, encoding="utf-8")
            return {"path": req.path, "written": len(req.content)}
        raise HTTPException(400, f"unknown action '{req.action}'")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, str(exc))


@app.delete("/api/files")
async def files_delete(path: str):
    t = _safe(path)
    if t.is_dir():
        if t == config.WORKSPACE_DIR:
            raise HTTPException(400, "cannot delete workspace root")
        shutil.rmtree(t)
    elif t.is_file():
        t.unlink()
    else:
        raise HTTPException(404, "not found")
    return {"deleted": path}


_ARCHIVE_SKIP = {".git", "__pycache__", "node_modules", ".venv", "venv",
                 "env", ".pytest_cache", ".mypy_cache", "backups", "data"}


_SENSITIVE_RE = re.compile(
    r"(^|\/)(\.env($|\..*)|.*\.(pem|key|pfx|p12|keystore|jks)$|id_rsa.*|.*secret.*|.*credential.*|.*\.token$)",
    re.IGNORECASE,
)


def _is_sensitive(path: str) -> bool:
    rel = str(path or "").replace("\\", "/").lstrip("/")
    while rel.startswith("./"):
        rel = rel[2:]
    return bool(_SENSITIVE_RE.search(rel))


def _archive_workspace_zip(dest: Path) -> Path:
    """Zip the global workspace into dest (safe: skips caches/venvs/secrets)."""
    root = config.WORKSPACE_DIR.resolve()
    dest = Path(dest).resolve()
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            try:
                rel = p.relative_to(root)
            except Exception:
                continue
            if any(part in _ARCHIVE_SKIP for part in rel.parts):
                continue
            if p.resolve() == dest or _is_sensitive(str(rel)):
                continue
            try:
                zf.write(p, str(rel).replace("\\", "/"))
            except Exception:
                continue
    return dest


@app.get("/api/files/download")
async def files_download(path: str):
    if _is_sensitive(path):
        raise HTTPException(403, "sensitive file blocked")
    t = _safe(path)
    if not t.is_file():
        raise HTTPException(404, "not a file")
    return FileResponse(str(t), filename=t.name)


@app.get("/api/files/archive")
async def files_archive():
    out = Path(config.WORKSPACE_DIR) / "workspace_export.zip"
    try:
        _archive_workspace_zip(out)
    except Exception as exc:
        raise HTTPException(500, str(exc))
    return FileResponse(str(out), filename="workspace.zip",
                        media_type="application/zip")


# --------------------------------------------------------------------- #
#  Universal execution API (runtime detection + real task engine)
# --------------------------------------------------------------------- #
class ExecTaskCreate(BaseModel):
    env: str = "auto"
    session_id: Optional[str] = None
    title: str = ""
    approved: bool = False


class ExecCommand(BaseModel):
    command: str = Field(min_length=1)
    timeout: int = 120
    shell: str = "auto"
    cwd: Optional[str] = None
    approved: bool = False
    background: bool = False


class ExecPython(BaseModel):
    code: str = Field(min_length=1)
    timeout: int = 60


class ExecFileWrite(BaseModel):
    path: str = Field(min_length=1)
    content: str = ""


@app.get("/api/runtime")
async def runtime_info(refresh: bool = False):
    s = runtime_env.summary(refresh=refresh)
    return {"ok": True, "summary": s,
            "environments": runtime_env.available_environments()}


@app.post("/api/runtime/refresh")
async def runtime_refresh():
    s = runtime_env.summary(refresh=True)
    return {"ok": True, "summary": s,
            "environments": runtime_env.available_environments()}


@app.get("/api/runtime/summary")
async def runtime_summary():
    return {"ok": True, "summary": runtime_env.summary()}


@app.get("/api/tools")
async def runtime_tools(refresh: bool = False):
    return {"ok": True, **runtime_env.tool_catalog(refresh=refresh)}


@app.get("/api/exec/capabilities")
async def exec_capabilities():
    return execution.capabilities()


@app.get("/api/exec/tasks")
async def exec_tasks(owner: Optional[str] = None,
                     session_id: Optional[str] = None,
                     limit: int = 50):
    return {"ok": True, "tasks": execution.list_tasks(owner=owner,
                                                      session_id=session_id,
                                                      limit=limit)}


@app.post("/api/exec/tasks")
async def exec_tasks_create(req: ExecTaskCreate):
    try:
        t = execution.create_task(env=req.env, session_id=req.session_id,
                                  title=req.title, approved=req.approved)
        return {"ok": True, "task": t}
    except execution.EnvironmentUnavailable as exc:
        raise HTTPException(409, {"error": exc.reason,
                                  "available": exc.available,
                                  "requested": exc.requested})
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/exec/tasks/{tid}")
async def exec_task_get(tid: str):
    t = execution.load_task(tid)
    if not t:
        raise HTTPException(404, "task not found")
    return {"ok": True, "task": execution.public_task(t)}


@app.delete("/api/exec/tasks/{tid}")
async def exec_task_delete(tid: str):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    execution.delete_task(tid)
    return {"ok": True, "deleted": tid}


@app.post("/api/exec/tasks/{tid}/approve")
async def exec_task_approve(tid: str, approved: bool = True):
    t = execution.load_task(tid)
    if not t:
        raise HTTPException(404, "task not found")
    t["approved"] = bool(approved)
    t["risk"] = t.get("risk") or "safe"
    execution.save_task(t)
    return {"ok": True, "task_id": tid, "approved": t["approved"]}


@app.post("/api/exec/tasks/{tid}/import")
async def exec_task_import(tid: str, file: UploadFile = File(...)):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    data = await file.read()
    try:
        res = execution.import_file(tid, file.filename or "upload.bin", data)
        return {"ok": True, "import": res}
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(500, str(exc))


@app.post("/api/exec/tasks/{tid}/exec")
async def exec_task_exec(tid: str, req: ExecCommand):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    try:
        res = await execution.run_command(
            tid, req.command, shell=req.shell, timeout=int(req.timeout or 120),
            cwd=req.cwd, approved=bool(req.approved),
            background=bool(req.background))
    except Exception as exc:
        raise HTTPException(500, str(exc))
    return {"ok": bool(res.get("ok")), "result": res,
            "task": execution.public_task(execution.load_task(tid) or {"id": tid})}


@app.post("/api/exec/tasks/{tid}/python")
async def exec_task_python(tid: str, req: ExecPython):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    try:
        res = await execution.run_python(tid, req.code, timeout=int(req.timeout or 60))
    except Exception as exc:
        raise HTTPException(500, str(exc))
    return {"ok": bool(res.get("ok")), "result": res}


@app.post("/api/exec/tasks/{tid}/cancel")
async def exec_task_cancel(tid: str):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    return {"ok": True, "cancel": execution.cancel(tid)}


@app.get("/api/exec/tasks/{tid}/files")
async def exec_task_files(tid: str):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    return {"ok": True, **execution.list_files(tid)}


@app.get("/api/exec/tasks/{tid}/file")
async def exec_task_file_get(tid: str, path: str):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    if _is_sensitive(path):
        raise HTTPException(403, "sensitive file blocked")
    try:
        return {"ok": True, **execution.read_file(tid, path)}
    except FileNotFoundError:
        raise HTTPException(404, "not found")
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/exec/tasks/{tid}/file")
async def exec_task_file_write(tid: str, req: ExecFileWrite):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    try:
        return {"ok": True, **execution.write_file(tid, req.path, req.content)}
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/exec/tasks/{tid}/download")
async def exec_task_download(tid: str, path: str):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    if _is_sensitive(path):
        raise HTTPException(403, "sensitive file blocked")
    try:
        p = execution.task_file_path(tid, path)
    except FileNotFoundError:
        raise HTTPException(404, "not found")
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return FileResponse(str(p), filename=p.name)


@app.get("/api/exec/tasks/{tid}/archive")
async def exec_task_archive(tid: str):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    try:
        art = execution.make_archive(tid)
    except Exception as exc:
        raise HTTPException(500, str(exc))
    return FileResponse(art["path"], filename=art["name"],
                        media_type="application/zip")


@app.get("/api/exec/tasks/{tid}/git")
async def exec_task_git_status(tid: str):
    """Real git status/log/branches for a task workspace."""
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    return {"ok": True, "task_id": tid,
            "status": git_ops.status(tid),
            "log": git_ops.log(tid),
            "branches": git_ops.branches(tid)}


class GitRequest(BaseModel):
    action: str = "status"
    message: str = ""
    paths: List[str] = []


@app.post("/api/exec/tasks/{tid}/git")
async def exec_task_git_action(tid: str, req: GitRequest):
    """Real git action inside the task workspace (status/diff/log/add/commit)."""
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    res = git_ops.run(tid, req.action, message=req.message,
                      paths=req.paths)
    return {"ok": bool(res.get("ok")), "task_id": tid, **res}


@app.get("/api/exec/tasks/{tid}/artifacts")
async def exec_task_artifacts(tid: str):
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")
    return {"ok": True, "artifacts": execution.list_artifacts(tid)}


@app.get("/api/exec/tasks/{tid}/events/stream")
async def exec_task_events_stream(tid: str, since: int = 0):
    """Live SSE of task events (polls the persisted task, capped loop)."""
    if not execution.load_task(tid):
        raise HTTPException(404, "task not found")

    async def gen():
        idx = max(0, int(since or 0))
        idle = 0
        while idle < 900:  # ~15 min max per connection
            t = execution.load_task(tid)
            if not t:
                yield f"data: {json.dumps({'type':'gone','data':tid})}\n\n"
                return
            events = t.get("events") or []
            if idx < len(events):
                for ev in events[idx:]:
                    yield f"data: {json.dumps(ev, ensure_ascii=False, default=str)}\n\n"
                idx = len(events)
                idle = 0
            else:
                idle += 1
                yield ": keepalive\n\n"
                await asyncio.sleep(1.0)
            if t.get("status") in ("succeeded", "failed", "cancelled"):
                yield f"data: {json.dumps({'type':'status','data':t.get('status')})}\n\n"
                return
        yield f"data: {json.dumps({'type':'timeout','data':tid})}\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


# --------------------------------------------------------------------- #
#  Long-term memory (RAG) + Phase 2 user profile memory
# --------------------------------------------------------------------- #
@app.get("/api/memory")
async def memory_view(q: Optional[str] = None, k: int = 8):
    items = memory.recall(q, k=k) if q else memory.recent(k=k)
    return {"engine": memory.engine_name(), "enabled": config.MEMORY_ENABLED,
            "items": items}


@app.get("/api/memory/status")
async def memory_status(user_id: str = "default"):
    prof = {}
    try:
        prof = user_memory.get_profile(user_id)
    except Exception:
        prof = {"user_id": user_id}
    try:
        recent = memory.recent(k=3)
    except Exception:
        recent = []
    populated = [k for k, v in (prof or {}).items() if k not in ("user_id", "last_updated") and v not in (None, "", [], {})]
    return {
        "ok": True,
        "engine": memory.engine_name(),
        "enabled": config.MEMORY_ENABLED,
        "profile": prof,
        "profile_fields": populated,
        "profile_ready": bool(populated),
        "recent_count": len(recent),
    }


@app.get("/api/memory/profile")
async def memory_profile_get(user_id: str = "default"):
    return {"profile": user_memory.get_profile(user_id)}


class MemoryProfileRequest(BaseModel):
    user_id: str = "default"
    updates: dict = Field(default_factory=dict)
    replace_lists: bool = False


@app.post("/api/memory/profile")
async def memory_profile_update(req: MemoryProfileRequest):
    prof = user_memory.save_profile(req.user_id or "default", req.updates or {}, replace_lists=bool(req.replace_lists))
    return {"ok": True, "profile": prof}


@app.delete("/api/memory")
async def memory_clear():
    deleted = memory.wipe()
    return {"deleted": deleted, "engine": memory.engine_name()}




# --------------------------------------------------------------------- #
#  Phase 3: Sandbox environments (session-oriented)
# --------------------------------------------------------------------- #
class SandboxStartRequest(BaseModel):
    distro: str = ""
    session_id: Optional[str] = None

class SandboxExecRequest(BaseModel):
    command: str = Field(min_length=1)
    timeout: int = 60
    shell: str = "powershell"

class SandboxSnapshotRequest(BaseModel):
    note: str = ""

class SandboxRestoreRequest(BaseModel):
    snapshot_id: str = Field(min_length=1)

@app.get("/api/sandbox/capabilities")
async def sandbox_capabilities():
    return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.capabilities)

@app.get("/api/sandbox/sessions")
async def sandbox_sessions():
    return {"sessions": await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.list_sessions)}

@app.post("/api/sandbox/{kind}/start")
async def sandbox_start(kind: str, req: SandboxStartRequest = SandboxStartRequest()):
    try:
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.start, kind, req.distro or "", req.session_id)
    except Exception as e:
        raise HTTPException(400, str(e))

@app.get("/api/sandbox/{sid}/status")
async def sandbox_status(sid: str):
    try:
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.status, sid)
    except KeyError:
        raise HTTPException(404, "sandbox session not found")
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/api/sandbox/{sid}/execute")
async def sandbox_execute(sid: str, req: SandboxExecRequest):
    try:
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.execute, sid, req.command, int(req.timeout or 60), req.shell or "powershell")
    except KeyError:
        raise HTTPException(404, "sandbox session not found")
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/api/sandbox/linux/exec")
async def sandbox_linux_exec_compat(sid: str, req: SandboxExecRequest):
    return await sandbox_execute(sid, req)

@app.get("/api/sandbox/{sid}/results")
async def sandbox_results(sid: str):
    try:
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.results, sid)
    except KeyError:
        raise HTTPException(404, "sandbox session not found")
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/api/sandbox/{sid}/snapshot")
async def sandbox_snapshot(sid: str, req: SandboxSnapshotRequest = SandboxSnapshotRequest()):
    try:
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.snapshot, sid, req.note or "")
    except KeyError:
        raise HTTPException(404, "sandbox session not found")
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/api/sandbox/{sid}/restore")
async def sandbox_restore(sid: str, req: SandboxRestoreRequest):
    try:
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.restore, sid, req.snapshot_id)
    except KeyError:
        raise HTTPException(404, "sandbox session not found")
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/api/sandbox/{sid}/upload")
async def sandbox_upload(sid: str, file: UploadFile = File(...)):
    try:
        data = await file.read()
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.upload, sid, file.filename or "upload.bin", data)
    except KeyError:
        raise HTTPException(404, "sandbox session not found")
    except Exception as e:
        raise HTTPException(400, str(e))

@app.delete("/api/sandbox/{sid}")
@app.post("/api/sandbox/{sid}/destroy")
async def sandbox_destroy(sid: str):
    try:
        return await asyncio.to_thread(sandbox_mgr.SANDBOX_MANAGER.destroy, sid)
    except KeyError:
        raise HTTPException(404, "sandbox session not found")
    except Exception as e:
        raise HTTPException(400, str(e))

# aliases matching spec-style names
@app.post("/sandbox/windows/start")
async def sandbox_windows_start_alias(req: SandboxStartRequest = SandboxStartRequest()):
    return await sandbox_start("windows", req)

@app.post("/sandbox/linux/start")
async def sandbox_linux_start_alias(req: SandboxStartRequest = SandboxStartRequest()):
    return await sandbox_start("linux", req)





# gateway bridge routes (gateway.py defines its own app; expose handlers on main app)
try:
    import gateway as _gw
    from fastapi import Request

    async def _gw_providers(): return await _gw.list_providers()
    async def _gw_add_provider(inp: _gw.ProviderIn): return await _gw.add_provider(inp)
    async def _gw_update_provider(pid: str, patch: _gw.ProviderPatch): return await _gw.update_provider(pid, patch)
    async def _gw_delete_provider(pid: str): return await _gw.delete_provider(pid)
    async def _gw_test(pid: str): return await _gw.test_provider(pid)
    async def _gw_sync(pid: str): return await _gw.sync_provider_models(pid)
    async def _gw_get_settings(): return await _gw.get_gateway_settings()
    async def _gw_post_settings(patch: _gw.SettingsPatch): return await _gw.save_settings(patch)
    async def _gw_patch_settings(patch: _gw.SettingsPatch): return await _gw.patch_settings(patch)
    async def _gw_models(free: int = 0, working: int = 1): return await _gw.list_gateway_models(free=free, working=working)
    async def _gw_catalog(q: str = "", provider: str = "", free: int = 0, limit: int = 400, offset: int = 0): return await _gw.gateway_catalog(q=q, provider=provider, free=free, limit=limit, offset=offset)
    async def _gw_custom_models(body: dict): return await _gw.add_custom_model(body)
    async def _gw_free_summary(): return await _gw.free_tier_summary()
    async def _gw_combo(combo: str): return await _gw.get_combo(combo)
    async def _gw_compress(body: dict): return await _gw.compression_preview(body)
    async def _gw_squad_plan(inp: _gw.SquadRunIn): return await _gw.squad_plan(inp)
    async def _gw_squad_run(inp: _gw.SquadRunIn, request: Request): return await _gw.squad_run(inp, request)

    app.add_api_route('/api/gateway/providers', _gw_providers, methods=['GET'])
    app.add_api_route('/api/gateway/providers', _gw_add_provider, methods=['POST'])
    app.add_api_route('/api/gateway/providers/{pid}', _gw_update_provider, methods=['PATCH'])
    app.add_api_route('/api/gateway/providers/{pid}', _gw_delete_provider, methods=['DELETE'])
    app.add_api_route('/api/gateway/providers/{pid}/test', _gw_test, methods=['POST'])
    app.add_api_route('/api/gateway/providers/{pid}/sync-models', _gw_sync, methods=['POST'])
    app.add_api_route('/api/gateway/settings', _gw_get_settings, methods=['GET'])
    app.add_api_route('/api/gateway/settings', _gw_post_settings, methods=['POST'])
    app.add_api_route('/api/gateway/settings', _gw_patch_settings, methods=['PATCH'])
    app.add_api_route('/api/gateway/models', _gw_models, methods=['GET'])
    app.add_api_route('/api/gateway/catalog', _gw_catalog, methods=['GET'])
    app.add_api_route('/api/gateway/custom-models', _gw_custom_models, methods=['POST'])
    app.add_api_route('/api/free-tier/summary', _gw_free_summary, methods=['GET'])
    app.add_api_route('/api/combos/{combo:path}', _gw_combo, methods=['GET'])
    app.add_api_route('/api/compression/preview', _gw_compress, methods=['POST'])
    app.add_api_route('/api/gateway/squad/plan', _gw_squad_plan, methods=['POST'])
    app.add_api_route('/api/gateway/squad/run', _gw_squad_run, methods=['POST'])
    log.info('Gateway bridge routes registered')
except Exception as _e:
    log.warning('Gateway bridge not registered: %s', _e)

# --------------------------------------------------------------------- #
#  Frontend SPA fallback (must stay last so API/docs routes win)
# --------------------------------------------------------------------- #
if (_FRONTEND_DIST / "index.html").is_file():
    from fastapi.staticfiles import StaticFiles

    _frontend_assets = _FRONTEND_DIST / "assets"
    if _frontend_assets.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_frontend_assets)),
                  name="frontend-assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def frontend_spa(full_path: str):
        if full_path.startswith(("api/", "docs", "redoc", "openapi.json")):
            raise HTTPException(404, "not found")
        candidate = (_FRONTEND_DIST / full_path).resolve()
        root = _FRONTEND_DIST.resolve()
        if (candidate == root or root in candidate.parents) and candidate.is_file():
            return FileResponse(str(candidate))
        return FileResponse(str(_FRONTEND_DIST / "index.html"),
                            headers={"Cache-Control": "no-cache"})


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
