"""Content safety filter (pattern-based, configurable)."""
from __future__ import annotations

import re
from typing import List

PATTERNS: List[str] = []


def add_pattern(p: str) -> None:
    PATTERNS.append(p)


def check(text: str) -> dict:
    hits = []
    for p in PATTERNS:
        if re.search(p, text, re.IGNORECASE):
            hits.append(p)
    return {"flagged": len(hits) > 0, "matches": hits}


def redact(text: str, replacement: str = "[REDACTED]") -> str:
    out = text
    for p in PATTERNS:
        out = re.sub(p, replacement, out, flags=re.IGNORECASE)
    return out
