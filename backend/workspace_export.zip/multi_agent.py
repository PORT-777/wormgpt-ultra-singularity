"""Multi-agent orchestrator: task distribution, shared context, aggregation."""
from __future__ import annotations

import time
import uuid
from typing import List, Dict, Optional, Callable

ORCHESTRATIONS: Dict[str, dict] = {}


def create(goal: str, agent_ids: List[str], max_steps: int = 50) -> dict:
    oid = uuid.uuid4().hex[:12]
    o = {"id": oid, "goal": goal, "agent_ids": agent_ids, "status": "pending",
         "started_at": None, "finished_at": None, "max_steps": max_steps,
         "steps": 0, "shared_context": {}, "results": [], "errors": []}
    ORCHESTRATIONS[oid] = o
    return o


def get(oid: str) -> Optional[dict]:
    return ORCHESTRATIONS.get(oid)


def list_all() -> List[dict]:
    return list(ORCHESTRATIONS.values())


def run(oid: str, agent_runner: Callable) -> dict:
    o = ORCHESTRATIONS.get(oid)
    if not o:
        return {"ok": False, "error": "not found"}
    o["status"] = "running"
    o["started_at"] = time.time()
    try:
        for aid in o["agent_ids"]:
            if o["steps"] >= o["max_steps"]:
                o["errors"].append("max steps reached")
                break
            res = agent_runner(aid, o["goal"], o["shared_context"])
            o["steps"] += 1
            o["results"].append({"agent_id": aid, "result": res})
            if isinstance(res, dict) and res.get("context_update"):
                o["shared_context"].update(res["context_update"])
        o["status"] = "completed"
    except Exception as e:
        o["status"] = "failed"
        o["errors"].append(str(e))
    o["finished_at"] = time.time()
    return o


def cancel(oid: str) -> bool:
    o = ORCHESTRATIONS.get(oid)
    if not o:
        return False
    o["status"] = "cancelled"
    o["finished_at"] = time.time()
    return True
